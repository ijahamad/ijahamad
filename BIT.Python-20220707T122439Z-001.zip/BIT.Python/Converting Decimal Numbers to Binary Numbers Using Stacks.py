class Stack:
    def __init__(self,numDec):
        self.items = [] #create new stack with no items
        self.NumDec = numDec
        self.NumBin=''
    def __str__(self):
        values = self.items.reverse()
        values = [str(x) for x in self.items]
        return ' '.join(values) 
    def isEmpty(self):
        return self.items == [] #check whether list if empty and retuen T or F
    def size(self):
        return len(self.items) #return size of stack (= length of list)
    def push(self,val):
        self.items.append(val) #add the argument pass to the end of list
    def pop(self):
        return self.items.pop() #return the last item in list because index not specified
    def peek(self):
        return self.items[-1] #return last item (-1 because from right indices are negative)
    def tobin(self):
        
        while self.NumDec>0:                           #loop till the number we divide is 1 or 0
            self.items.append(self.NumDec%2)             #add the remainder when divide by 2 to stack
            self.NumDec=self.NumDec//2    #change the number to be divide to the whole number when divided by 2

        #return self.items
##      while (len(self.NumBin) != 0):
##           a=self.items.pop()
##           print(a)

NumDec = int(input("Enter the number :- "))
customStack = Stack(NumDec)
abc = customStack.tobin()
print("Binary Number :- ",customStack)
print(abc)



