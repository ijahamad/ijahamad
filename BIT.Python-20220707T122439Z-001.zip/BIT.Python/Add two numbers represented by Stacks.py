# Python3 program to implement
# the above approach
 
# Function to return the stack that
# contains the sum of two numbers
def addStack(N1, N2):
 
    res = []
    s = 0
    rem = 0
 
    while (len(N1) != 0 and len(N2) != 0):
 
        # Calculate the sum of the top
        # elements of both the stacks
        s = (rem + N1[-1] + N2[-1])
 
        # Push the sum into the stack
        res.append(s % 10)
 
        # Store the carry
        rem = s // 10
 
        # Pop the top elements
        N1.pop(-1)
        N2.pop(-1)
 
    # If N1 is not empty
    while(len(N1) != 0):
        s = rem + N1[-1]
        res.append(s % 10)
        rem = s // 10
        N1.pop(-1)
 
    # If N2 is not empty
    while(len(N2) != 0):
        s = rem + N2[-1]
        res.append(s % 10)
        rem = s // 10
        N2.pop(-1)
 
    # If carry remains
    while(rem > 0):
        res.append(rem)
        rem //= 10
 
    # Reverse the stack.so that
    # most significant digit is
    # at the bottom of the stack
    res = res[::-1]
 
    return res
 
# Function to display the
# resultamt stack
def display(res):
 
    s = ""
    for i in res:
        s += str(i)
 
    print(s)
 
# Driver Code
N1 = []
N1.append(5)
N1.append(8)
N1.append(7)
N1.append(4)
 
N2 = []
N2.append(2)
N2.append(1)
N2.append(3)
 
# Function call
res = addStack(N1, N2)
 
display(res)
