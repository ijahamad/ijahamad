#___________________Creating a stack__________________

def create_stack():
    stack = []              #creating an empty list
    print("stack")
    return stack



#_____________Create an empty stack___________________

def check_empty(stack):
    return len(stack) == 0  #return boolean value


 
#_____________Adding item into the stack___________________

def push(stack,item):         #we have passed a stack which we created earlier and then we are passing a item value as well
    stack.append(item)
    print("pushed item: ",item)
    


#_____________Removing an element from the stack___________________

def pop(stack):
   if(check_empty(stack)):
     return "stack is empty" 

   return stack.pop()

def peek(stack):
    if (check_empty(stack)):
        return "There is no elements in the stack"
    else:
        return stack[len(stack)-1]




stack=create_stack()
push(stack,12)       #function calling
push(stack,11)       #function calling
push(stack,10)       #function calling
print("stack.pop() :- ",pop(stack))
print("stack after popping an element: ",stack)
print(check_empty(stack))
print("peek(stack) :- ",peek(stack))









##def create_stack():
##    stack = []
##    return stack
##
##def push (stack,value):
##    stack.append(value)
##    print ("The value is : ",value)
##    
##    
##
##
##def pop (stack):
##    if len(stack) == 0:
##        return "stack is empty"
##    else:
##        return stack.pop()
##
##def delete (stack,value):
##    del stack[value]
##    print(stack)
##
##
##
##
##stack=create_stack()
##push(stack,32)
##push(stack,10)
##push(stack,2)
##pop(stack)
##print(stack)
##delete(stack,1)
    

