
s = "Ma"
l = len(s)
if l < 2:
    print("hi")

elif s[0] == s[l - 1]:
    print("ho")


else:
    print("bye")
print("(s[1: l - 1]):-",(s[1: l - 1]))
print(s[1-1])

            



import array as ijas

name=ijas.array("I",[21,3,43,54,12])
#name = ijas.array("I",[21,-3,43,-54,12])    #OverflowError: can't convert negative value to unsigned int
print(name)
print(ijas.array)
print(type(name))
print(name.buffer_info())
print(name.typecode)
name.reverse()
print(name)

for i in range(5):
    print ("name [i] :- ",name [i])

print("-------------------------------------------------------------------------")

for i in range(len(name)):
    print ("name [i] :- ",name [i])

print("-------------------------------------------------------------------------")

for i in name:
    print ("i :- ",i)
    
newArr = ijas.array(name.typecode,(a for a in name))


for i in newArr:
    print("newArr :- ",i)

print("-------------------------------------------------------------------------")

name = ijas.array("i",[21,-3,43,-54,12])
print(name)


print("-------------------------------------------------------------------------")


import array as ahamad

character=ahamad.array ('u',['a','b','c','d'])

print(character)

for i in character:
    print ("i :- ",i )



 
