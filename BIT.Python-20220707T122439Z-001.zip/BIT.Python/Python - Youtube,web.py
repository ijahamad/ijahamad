x=10/2
print("x=10/2 :- ",x)                # print is an inbuilt function.

x=10//2
print("x=10//2 :- ",x)

x=10%3
print("x=10%3 :- ",x)

y=8+2*3
print("y=8+2*3 :- ",y)

y=(8+2)*3
print("y=(8+2)*3 :- ",y)

z=2*2*2
print("z=2*2*2 :- ",z)

z=2**3
print("z=2**3 :- ",z)

name='Ijas'
print(name)                

abc="Navin's laptop"
print(abc)

abc='Navin\'s laptop\n'
print(abc)

print(10*abc)
print(r'c:\docs\navin')

x=2
y=7
print(x+y)

print(x+10)
   
print("-------------------------------------------------------------------------------")
laptop="keyboard"
print("laptop[:] :- ",laptop[:])
print("laptop[3:] :- ",laptop[3:])
print("laptop[:3] :- ",laptop[:3])
print("laptop+\"Hardware\" :- ",laptop+"Hardware")
print("laptop[3:7] :- ",laptop[3:7])
print("laptop[-1] :- ",laptop[-1])
print("laptop[-7] :- ",laptop[-7])
print("laptop[-1] :- ",laptop[-1])
print("laptop[3:20] :- ",laptop[3:20])
print("'my '+ laptop :- ","my "+laptop[3:])
print("len(laptop) :- ",len(laptop))
print("laptop[len(laptop)-1] :- ",laptop[len(laptop)-1])

print("\n-------------------------------------------------------------------------------")

def add(n1,n2):
    n3=n1*n2
    return n3

a=int(input("Enter the number: "))
b=int(input("Enter the number: "))

c=add(a,b)
print(c)

print("\n-------------------------------------------------------------------------------")

def ijas(name):
    ija=name
    print( ija)
   

print("\n---------------------------------------------------------------------------")


s = "This is a string"
print(s)
s = '''A multiline
string'''
print(s)

