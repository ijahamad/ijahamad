def fact(n):

    f = 1
    for i in range(1,n+1):
        f=f*i

    return f

x=5
result = fact(x)
print (result)

print ("-------------------------------------------------------------------------------")

def factorial (n):
    if (n==0 or n==1):  #Because 0 factor is 1 and 1 factor is 1
        return 1
    else:
        return n*factorial(n-1)


n=int(input("Enter n.value: "))
result = factorial(n)
print (result)


print ("-------------------------------------------------------------------------------")

def greet(value):
    if (value<=0):
        print("Ended")
    else:
        print(value)
        rev(value-1)
        
   

greet(10)


