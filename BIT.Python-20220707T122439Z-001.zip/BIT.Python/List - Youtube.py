nums=[21,32,43,54]
print("nums :- ",nums)
print("nums[0] :- ",nums[0])
print("nums[-1] :- ",nums[-1])
print("nums[0:3] :- ",nums[0:3])
print("nums[0:3] :- ",nums[:])
nums.

print("\n---------------------------------------------------\n")

names=["Ijas","Ahamad","Kamal"]
print("names :- ",names)
print("names[0] :- ",names[0])

print("\n---------------------------------------------------\n")

nums.insert(1,20)
print("nums.insert(1,20) :- \n",nums)

print("\n---------------------------------------------------\n")

nums.remove(32)
print("nums.remove(32) :- ",nums)

print("nums.pop(2) :- ",nums.pop(2))
print("nums :- ",nums)

print("\n---------------------------------------------------\n")

nums.extend([12,23,34])
print("nums :- ",nums)
print("\nnums.extend([12,23,34])",nums)

nums.extend("12,23,34")
print('\nnums.extend("12,23,34")',nums)

nums.extend("A")
print('\nnums.extend("A") :- ',nums)

nums.extend("ijas")
print('\nnums.extend("ijas") :- ',nums)

nums.extend("3")
print('\nnums.extend("3") :- ',nums)

nums.extend([32])
print("\nnums.extend([32]) :- ",nums)


nums.extend("32")
print(nums)

print("\n---------------------------------------------------\n")

numbers = [1,23,43,45]
print("numbers :- ",numbers)
print("\nmin(numbers) :- ",min(numbers))

#print("---------------------------------------------------")

print("max(numbers) :- ",max(numbers))

print("\n---------------------------------------------------\n")

print("sum(numbers) :- ",sum(numbers))

numbers.sort()
                
print("numbers.sort()  \nprint(numbers) :- ",numbers)

print("\n---------------------------------------------------\n")


print("len(numbers) :- ",len(numbers))
print("numbers[len(numbers)-1] :- ",numbers[len(numbers)-1])

#print(numbers[len(numbers)])               #IndexError: list index out of range













