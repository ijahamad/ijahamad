# Python3 program to check for
# balanced brackets.
 
# function to check if
# brackets are balanced
 
 
def are_Brackets_Balanced(expr):
    stack = []
 
    # Traversing the Expression
    for char in expr:
        if char in ["(", "{", "["]:
 
            # Push the element in the stack
            
            stack.append(char)
            
        else:
 
            # IF current character is not opening
            # bracket, then it must be closing.
            # So stack cannot be empty at this point.
            
            if not stack:
                return False
            
            current_char = stack.pop()
           
            
            if current_char == '(':
                
                if char != ")":
                    return False
                
            if current_char == '{':
                
                if char != "}":
                    return False
                
            if current_char == '[':
               
                if char != "]":
                    return False
 
    # Check Empty Stack
    if stack:
        return False
    return True
 
 

expr = "{()}[]"
 
# Function call
if are_Brackets_Balanced(expr):
    print("Balanced")
else:
    print("Not Balanced")
 
