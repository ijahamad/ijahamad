
#_________stacks___________

numbers=[]
numbers.append(1)
numbers.append(2)
numbers.append(3)
numbers.append(4)
print (numbers)
print (numbers[-1])
print(numbers.pop())
print (numbers)
print (numbers[-1])
