print("---------------- Generators-------------------")

def numbers():
    yield 5
    yield 5
    yield 5
    yield 5

values=numbers()

print("next(values) :- ",next(values))

for i in values:
    print("For loop :- ",i)

print("---------------------------------------------------------------------")

def topten():
    n=1
    while n<=10:
        sq = n*n
        yield sq
        n+=1
        
val = topten()

for i in val:
    print("For loop :- ",i)
    
print("---------------- Iterator-------------------")
num = [1,2,3,4]

it = iter(num)
print(it.__next__())
print(it.__next__())
print(next(it))
print(it.__next__())
print(it.__next__())  #Error :- StopIteration

for i in num:
    print("For loop :- ",i)




