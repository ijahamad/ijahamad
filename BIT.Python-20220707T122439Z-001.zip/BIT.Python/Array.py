
#_________________________Array__________________________________________

import array as arr 
a=arr.array("i",[2,44,6,8])
print("First element: ",a[0])
print(a)
print(a[-1])
print(a[-2])
