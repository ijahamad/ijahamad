#____________Set_________________

ijas = {12,"qwe",23,4,"e"}
print(ijas)
print("ijas.pop():-",ijas.pop())


print("-------------------------------------------------------------------")

#____________Tuple_________________

ahamad = ("q",2,342,'d')
print(ahamad)
ahamad.count("q")
print("ahamad.count('q'):-",ahamad.count("q"))
print("ahamad.count(123):-",ahamad.count(123))
print("ahamad.index(2):-",ahamad.index(2))
