
#___________________________List______________________________________________

Year=["January","February",3,"April","May","June","J","Augest"]
print ("Year :- ",Year)
print(Year[2],Year[1])             #3trd,2nd elements
print("Year[len(Year)-1] :- ",Year[len(Year)-1])           #Last element
print ("Year[8-1] :- ",Year[8-1])
print ("len(Year) :- ",len(Year))
print("Year[-1] :- ",Year[-1])                             #Last element

print ("----------------------------------------------------------------------")
print ("----------------------------------------------------------------------")

#________append__________

Year.append("September")          #add an element at the end of the list
Year.append("i")
print (Year)

print ("----------------------------------------------------------------------")
print ("----------------------------------------------------------------------")

#________extend__________
#Year.extend(Year)

#print (Year)
Year.extend("January")
print (Year)

#Year.extend("a","b")            #TypeError: list.extend() takes exactly one argument (2 given)
#print (Year)

#Year.extend("2")
#Year.extend(2)                  #TypeError: 'int' object is not iterable
#print (Year)

print ("----------------------------------------------------------------------")

#B=["A","B","C",1,2,3]
#Year.extend(B)
#print (Year)

print ("----------------------------------------------------------------------")

Year.insert(9,"October")         #inserting element to a selected index

print (Year)

print ("----------------------------------------------------------------------")

#________remove__________

Year.remove("January")           #remove elements

print ("----------------------------------------------------------------------")
#Year.remove("December")        #Error: list.remove(x): x not in list


print(Year)

print ("----------------------------------------------------------------------")
print ("----------------------------------------------------------------------")

#________index__________
print(Year.index("April"))       #obtaining the index of an element

print ("----------------------------------------------------------------------")
print ("----------------------------------------------------------------------")

#obtaining number of times a speindex of an element

#__________________popping  elements

#Year.pop()
#print(Year)
print("Year.pop() :- ",Year.pop())
print ("=================++++++++++++++========================================")
print("Lisr after popping the last element: ",Year)

print("Year.pop(3) :- ",Year.pop(3))
print ("=================++++++++++++++========================================")

print("Lisr after popping the last element: ",Year)

print ("----------------------------------------------------------------------")
print ("----------------------------------------------------------------------")



#______obtaining number of times a specific element appears in the list__________

Year.append(3)
print (Year.count(3))

