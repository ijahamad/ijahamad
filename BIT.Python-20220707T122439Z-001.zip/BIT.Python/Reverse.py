
class Queue:
    
    def __init__(self):
        self.data = []
        
    def isEmpty(self):
        return self.data == []
    
    def enQueue(self, data):
        self.data.insert(0,data)
        
    def deQueue(self):
        return self.data.pop()

    
def Reverse():
    if(Q.isEmpty()):
        return
    temp = Q.data[-1]
    Q.deQueue()
    Reverse()
    Q.enQueue(temp)
    
Q = Queue()
Q.enQueue(5)
Q.enQueue(4)
Q.enQueue(3)
Q.enQueue(2)
Q.enQueue(1)
print(Q.data)
Reverse()
print(Q.data)

print("------------------------------------------------------------------")

def reverse(text):
    text = text[::-1]
    return text

text = input("Enter the text : ")
print("reverse(text) :- ",reverse(text))

string="hihello"
print(string[::-1])

