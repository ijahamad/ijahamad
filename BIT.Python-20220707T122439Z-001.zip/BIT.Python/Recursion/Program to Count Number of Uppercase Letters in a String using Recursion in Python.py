def cntUpprCase_chactrs(gvn_strng, p):
  # Make the cnt a global declaration.
    global cnt
    # Check if the character present at the index p of the given string is greater than or
    # equal to 'A' and less than or equal to 'Z' using the if conditional statement.
    if (gvn_strng[p] >= 'A' and gvn_strng[p] <= 'Z'):
        # If the statement is true, then increment the value of cnt by 1 and store it in the
        # same variable.
        cnt += 1
    # Check if the value of p is greater than 0 using the if conditional statement.
    if (p > 0):
        # If the statement is true, pass the given string and p-1 as the arguments to the
        # cntUpprCase_chactrs function.{Recursive logic}
        cntUpprCase_chactrs(gvn_strng, p - 1)
    # Return the value of cnt.
    return cnt
# Give the string as static input and store it in a variable.
gvn_strng = "Hello This is Btechgeeks"
# Take a variable say cnt and initialize its value to 0.
cnt = 0
# Pass the given string and length of the given string-1 as the arguments to the
# cntUpprCase_chactrs function and store it in a variable rslt_cnt.
rslt_cnt = cntUpprCase_chactrs(gvn_strng, len(gvn_strng)-1)
# Check if the value of rslt_cnt is equal to 0 using the if conditional statement.
if(rslt_cnt == 0):
  # If the statement is true, then print "There are no UpperCase characters in a given
  # string".
    print("There are no UpperCase characters in a given string")
else:
  # Else print the number of uppercase characters present in the above-given string.
    print(
        "The Number Of UpperCase characters Present in the above given String {", gvn_strng, "} =", rslt_cnt)
