def solve(s):
   words = s.split(' ')
   ret = []
   for i in words:
      ret.append(i.capitalize())
   return ' '.join(ret)

s = "i love my country"
print(solve(s))
