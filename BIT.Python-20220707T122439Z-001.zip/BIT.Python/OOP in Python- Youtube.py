#everything is object in python
#str,int :- inbuilt class




class ijas:
    name="ahamad"
    age=21
    
    def details(self):
        abc="local variable"
        print (abc)
        print("Instance variable=",self.age)
        print ("Hi Ijas")

myself=ijas()
myself2=ijas()


ijas.details(myself)
print("\n---------------------------------------------------------------------------")
myself.details()
print("\n---------------------------------------------------------------------------")
myself2.details()


print("\n---------------------------------------------------------------------------")

print("myself.name=",myself.name)

print("myself.age=",myself.age)

print("\n---------------------------------------------------------------------------")        

#print("ijas.name=",ijas.name)
#print("ijas.age=",ijas.age)

print("myself2.name=",myself2.name)
print("myself2.age=",myself2.age)

print("\n---------------------------------------------------------------------------")

# -----------------------------++++++++++++++++++++++++++++++++++++++++++++++++++++++-------------------------------------------






        

