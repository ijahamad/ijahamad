class Stack:
    
    def __init__(self):
        self.items = []
 
    def isEmpty(self):
        return self.items == []
 
    def push(self, data):
        self.items.append(data)
 
    def pop(self):
        return self.items.pop()
 
 
customStack = Stack()                             #creating the object

#text = input('Please enter the string: ')
 
#for i in text:
customStack.push("asdf")
 
popped_text = ''                                  #initialize as string
while customStack.isEmpty():
    popped_text += customStack.pop()

 
if text == popped_text:
    print('The string is a palindrome.')
else:
    print('The string is not a palindrome.')

