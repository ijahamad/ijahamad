#stack implementation using list with the size limits
#max elements is predefined

class stack:

  def __init__(self,maxSizee):
    self.maxSize = maxSizee
    self.list =  []                          #creating empty stack

  def __str__(self):
    values = self.list.reverse()
    values=[str(x) for x in self.list]
    return '\n'.join(values)                 #print elements from top to bottom-stack wise

  def isEmpty(self):
    if self.list == []:
      return True
    else:
      return False

  def isfull(self):
    if len(self.list) == self.maxSize:
      return True
    else:
      return False

#push operation.Not checking the size

  def push(self,value):
    
      if self.isfull():
        return "Stack is full"
      else:
        self.list.append(value)
        return "The element has been successfully inserted"

#pop operation .check first if the stack is empty or not

  def pop(self):
    if self.isEmpty():
      return "There is no elements in the stack"
    else:
      return self.list.pop()

#peek method

  def  peek(self):
    if self.isEmpty():
      return "There is no elements in the stack"
    else:
      return self.list[len(self.list)-1]

#delete etire stack
  def delete(Self):
    self.list = None


customStack = stack(3)                                           #creating the object
print("customStack.isEmpty() :- ",customStack.isEmpty())
customStack.push(3)
print("customStack.push(2) :- ",customStack.push(2))
print("customStack.push(1) :- ",customStack.push(1))
print("customStack.push(4) :- ",customStack.push(4))
#customStack.pop()
print("customStack.pop() :- ",customStack.pop())
print("customStack :-  ",customStack)
print("customStack.isfull() :- ",customStack.isfull())
#customStack.peek()
print("customStack.peek() :- ",customStack.peek())
print("customStack.maxSize :- ",customStack.maxSize)



a= input("Enter a word: ")

for i in a:
    customStack.push(i);
    list1 = customStack.pop();

if(list1 == a):
    print("The word is a palindrome");
else:
    print("It's not a palindrome");
    print(a);
    print(list1);









  
  
