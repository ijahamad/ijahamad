#___________________Creating a stack__________________

def create_stack1():
    stack1 = []              #creating an empty list
    
    return stack1

def create_stack2():
    stack2 = []              #creating an empty list
    
    return stack2

##def create_stack3():
##    stack3 = []              #creating an empty list
##    
##    return stack3



#_____________Create an empty stack___________________

def check_empty(stack1):
    return len(stack1) == 0  #return boolean value

def check_empty(stack2):
    return len(stack2) == 0  #return boolean value




 
#_____________Adding item into the stack___________________

def push1(stack1,item1):         #we have passed a stack which we created earlier and then we are passing a item value as well
    stack1.append(item1)
    print("pushed item: ",item1)

def push2(stack2,item2):         #we have passed a stack which we created earlier and then we are passing a item value as well
    stack2.append(item2)
    print("pushed item: ",item2)



 
def add(stack1, stack2):
 
    res = []
    s = 0
    rem = 0
 
    while (len(stack1) != 0 and len(stack2) != 0):
 
        # Calculate the sum of the top
        # elements of both the stacks
        s = (rem + stack1[-1] + stack2[-1])
 
        # Push the sum into the stack
        res.append(s % 10)
 
        # Store the carry
        rem = s // 10
 
        # Pop the top elements
        stack1.pop(-1)
        stack2.pop(-1)
 
    # If stack1 is not empty
    while(len(stack1) != 0):
        s = rem + stack1[-1]
        res.append(s % 10)
        rem = s // 10
        stack1.pop(-1)
 
    # If stack2 is not empty
    while(len(stack2) != 0):
        s = rem + stack2[-1]
        res.append(s % 10)
        rem = s // 10
        stack2.pop(-1)


    while (len(res) != 0):
        a=res.pop()
        print(a)
    
 
##    # If carry remains
##    while(rem > 0):
##        res.append(rem)
##        rem //= 10
## 
##    # Reverse the stack.so that
##    # most significant digit is
##    # at the bottom of the stack
    #res = res[::-1]
    #return res


        
 
## Function to display the
## resultamt stack
##def display(res):
##
        
##    s = " "
##    for i in res:
##        s += str(i)
## 
##    print(s)
## 

stack1=create_stack1()
stack2=create_stack2()


push1(stack1,2)       #function calling
push1(stack1,8)       #function calling
push1(stack1,7)       #function calling
push1(stack1,4)       #function calling

push2(stack2,2)       #function calling
push2(stack2,1)       #function calling
push2(stack2,3)       #function calling



#print("stack.pop() :- ",pop(stack))
print("stack1 :- ",stack1)
print("stack2 :- ",stack2)
#print(check_empty(stack))
#print("peek(stack) :- ",peek(stack)) 

res = add(stack1,stack2)
 

