nums=[21,32,43,54]
print(nums)
print(nums[0])
print(nums[-1])

print("---------------------------------------------------")

names=["Ijas","Ahamad","Kamal"]
print(names[0])

nums.insert(1,20)
print(nums)


nums.remove(32)
print(nums)

print("   ",nums.pop(2))
print(nums)
