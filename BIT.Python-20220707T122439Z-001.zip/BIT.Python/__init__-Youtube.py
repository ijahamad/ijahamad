#Usage of init
print("--------------------------------A class without init----------------------------")

class Student:
     pass

stu1 = Student()
stu2 = Student()

stu1.name = "Kamal"
stu1.rollno = 100
stu1.dob = 2000

stu2.name = "Sunimal"
stu2.rollno = 200
stu2.dob = 1990

print(stu1.name)
print(stu2.name)

print("--------------------------------__init__----------------------------")

from datetime import date
class Student:
     fees = 10000
     def __init__(self,name,rollno,dob):
          self.name = name
          self.rollno = rollno
          self.dob = dob

     def age(self):
          current_year = date.today().year
          return current_year - self.dob


stu1 = Student("Kamal",100,2000)
stu2 = Student("Sunimal",200,1990)

print("stu1.name :- ",stu1.name)
print("stu2.name :- ",stu2.name)

print("stu1.age() :- ",stu1.age())
print("stu2.age() :- ",stu2.age())

print(stu1.fees)
print(stu2.fees)


print("------------------------------------------------------------------------------")



#stack implementation using list with the size limits
#max elements is predefined
class ijas:


     def __init__(self,agee,noo):
      self.age=agee
      self.no=noo
      self.address="23\qwer"
      self.laptop="Dell"
     
      
   


name=ijas(25,2323)
name2=ijas(24,25425)
print("type(name) :- ",type(name))
print("------------------------------------------------------------------------")

print("id(name) :- ",id(name))
print("id(name2) :- ",id(name2))

print("------------------------------------------------------------------------")


print("name.agee,name.noo :- ",name.age,name.no)
print("name2.agee,name2.noo :- ",name2.age,name2.no)
print("name.address,name.laptop :- ",name.address,name.laptop)
print("name2.address,name2.laptop :- ",name2.address,name2.laptop)

print("------------------------------------------------------------------------")

name.agee=27
name.noo=9909
name2.agee=30
name2.noo=101010

print("name.agee,name.noo :- ",name.agee,name.noo)
print("name2.agee,name2.no :- ",name2.agee,name2.noo)
