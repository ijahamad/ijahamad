def strChange(lst):
    ch=''
    for i in range(len(lst)):
        if lst[i]>='a' and lst[i]<='z' :
            print(ord(lst[i]))
            print(chr(ord(lst[i])-32))
            
            ch+=chr(ord(lst[i])-32)
    return ch
caps =  eval(input("Enter list: "))
caps2 = []
for i in range(len(caps)):
    a = strChange(caps[i])
    caps2.append(a)
print(caps2)
