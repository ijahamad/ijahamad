
def tobin (value):
    number = value
    stack = []      
    i=1

    while number!=0:
     x=number%2
     stack.append(x)
     number=number//2
     i=i+1
     
    stack.reverse()
    print(stack)
     
    
    

tobin(233)
tobin(50)
    



     
