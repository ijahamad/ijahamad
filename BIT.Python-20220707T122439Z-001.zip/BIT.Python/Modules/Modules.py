import calc                          

a = 9
b = 7

print("calc.add(a,b) :- ",calc.add(a,b))

print("----------------------------------Or----------------------------------------")

from calc import add         #So in the one line we can say add in the next line we can say import sub 

a=9
b=7

print("add(a,b) :- ",add(a,b))

print("----------------------------------Or----------------------------------------")

from calc import *           # * :- It will import all the functions for us

a=9
b=7

print("add(a,b) :- ",add(a,b))
print("sub(a,b) :- ",sub(a,b))
