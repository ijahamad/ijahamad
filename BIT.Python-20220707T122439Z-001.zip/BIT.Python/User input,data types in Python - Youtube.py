x = 5
y=10
z=x+y
print (z)

a=int(input("Enter the number:- "))
b=int(input("Enter the number:- "))
print("a+b :- ",a+b)

char=input("Enter a char :- ")[0]
print("char :- ",char)

exp=eval(input("Enter a exp :- "))
print("exp :- ",exp)
q=2.3
z=5
print("type(q :- ",type(q))
r=int(q)
print("type(r) :- ",type(r))
print("type(z) :- ",type(z))
t=float(z)
print("type(t) :- ",type(t))
num=6+9j
print("type(num :- ",type(num))
com=complex(t)
print("type(com) :- ",type(com))

hi=q>0
print("hi :- ",hi)
print("type(hi) :- ",type(hi))

print("int(True) :- ",int(True))
print("int(False) :- ",int(False))
st='a'
print(type(st))
print(list(range(10)))
print(list(range(2,10,2)))
print(type(range(10)))

dictionary = {'navin':'iphone','Rahul':'samsung','Kiran':'Oneplus'}
print(dictionary )
print(dictionary.keys())
print(dictionary.values())
