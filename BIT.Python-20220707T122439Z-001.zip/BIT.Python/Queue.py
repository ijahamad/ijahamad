#implementing queue with no capacity

class Queue:

 def __init__(self):
     
     self.item = []
 
 def  __str__(self):
     
     values = [str(x) for x in self.item]
     return '\t' .join(values)

 def isEmpty(self):
     
     if self.item == []:              #Or len(self.item) == 0       
         return True                  #if empty, return True
     else:
         return False
     

 def enqueue(self,value):
     
     self.item.append(value)
     return "Element is inserted at the end of the queue"

 def dequeue(self):                       #def dequeue(self):    
     if self.isEmpty():                    #   if len(self.item) == 0: 
         return "There is no element"      #       return "There is no element"
     else:                                 #  else:
         return self.item.pop(0)            #      return self.item.pop()

 def peek(self):
     if self.isEmpty():
         return "There is no element in the queue"
     else:
         return self.item[0]

 def delete (self):
     
     self.item = None
    
     
customQueue=Queue()
print("customQueue.dequeue() :- ",customQueue.dequeue())
print("customQueue.enqueue(3) :- ",customQueue.enqueue(3))
print("customQueue.enqueue(32) :- ",customQueue.enqueue(32))
print("customQueue.enqueue(343) :- ",customQueue.enqueue(343))
print("customQueue.enqueue(31) :- ",customQueue.enqueue(31))
print("customQueue :- ",customQueue)
print("customQueue.isEmpty() :- ",customQueue.isEmpty())

print("customQueue.dequeue() :- ",customQueue.dequeue())

