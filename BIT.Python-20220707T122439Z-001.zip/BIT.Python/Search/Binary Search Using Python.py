
def search(list,n):
    global pos
    pos=-1
    L = 0
    U = len(list)-1

    
    while L <= U:
        mid = (L+U) // 2
        
        if list[mid] == n:
            pos=mid
            return True
        else:
            if list[mid] < n:
                L = mid+1
                
            else:
                U = mid-1
                

    return False

list = [2,5,8,26,63,94]
n = 94

if search (list,n):
    print("Found at ",pos+1)

else:
    print("Not found")
