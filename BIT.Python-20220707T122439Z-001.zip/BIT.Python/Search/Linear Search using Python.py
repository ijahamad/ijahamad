

def search(list,n):
    global pos
    pos=-1
    i = 0

    while i < len(list):
        if list[i] == n:
            pos = i
            return True
        i = i+1

    return False

list = [5,2,8,6,9,6]
n = 6

if search (list,n):
    print("Found at ",pos+1)

else:
    print("Not found")
