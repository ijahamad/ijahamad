#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int counter=1,total=0;
    int average;
    int grade;


    while (counter<=10)

    {
        printf("enter marks: ");
        scanf("%d",&grade);
        total=total+grade;
        counter=counter+1;
    }
     average = total / 10;
    printf("class average is %d\n",average);


}
