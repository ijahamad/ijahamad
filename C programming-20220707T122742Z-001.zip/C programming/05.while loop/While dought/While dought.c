#include <stdio.h>
#include <stdlib.h>

int main()
{
unsigned int counter;
unsigned int grade;
int total;
float avarage;

 total=0;
counter=0;

 printf("%s","Enter grade ,-1 to end : ");
scanf("%d",&grade);

 while(grade!=-1)
{

total=total+grade;


printf("Enter grade ,-1 to end : ");
scanf("%d",&grade);
counter=counter+1;

 }
if(counter!=0)
{

avarage=(float)total/counter;
printf("\nClass average is:%f.\n",avarage);

}
else
{
puts("\nNo grades were entered.");

}
}
