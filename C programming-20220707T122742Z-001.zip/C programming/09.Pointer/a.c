#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a=5;
    int *p;

    p=&a;
    printf("address of a:%u\n",p);
    printf("value of a:%d\n",++*p);
    printf("value of a:%d",a);

}
