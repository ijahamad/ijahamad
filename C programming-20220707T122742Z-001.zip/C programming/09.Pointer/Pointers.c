#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int* p;
    int i=100;
    p=&i;


    printf("%d\n",i);
     printf("%u\n",p);
      printf("%u\n",&i);
       printf("%u\n",&p);
        printf("%d\n",*p );


}
