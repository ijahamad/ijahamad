#include <stdio.h>
#include <stdlib.h>

int main(void)
{
     char name[10];

     printf("enter your name: ");
     scanf("%s",&name);

 
}
