01)The length of the string.
a)
#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str2[]="to be or not to be";

    int count=0;

   while(str2[count]!='\0')
   {

    ++count;
   }
   printf("The length of the string is: %d",count);
}

------------------------------------------------------------------------------------------
b)

#include <stdio.h>
#include <stdlib.h>
int main()
{

char str1[]="La";
char str2[]="To be or not to be";
int count=0;
while(str1[count]!='\0')
{
    ++count;
}
printf("The length of the string \"%s\" is %d characters:\n",str1,count);


int j=0;
//while(str2[i]!='\0')

for(int i=0;str1[i]!='\0';++i)
{
  ++j
}
printf("The length of the string \"%s\" is %d characters:\n",str2,j);
}
