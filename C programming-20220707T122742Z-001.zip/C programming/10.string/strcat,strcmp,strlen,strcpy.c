#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[20];
    char str2[25];
    int i;

    printf("Enter the first name: ");
    scanf("%s",str1);

    i=strlen(str1);
    printf("\nThe length is: %d\n",i);

    strcpy(str2,str1);
    printf("\nCopy of the 'str1' is : %s\n",str2);


    printf("\nEnter the last name: ");
    scanf("%s",str2);

    printf("\nFull name is : %s\n",strcat(str1,str2));

    printf("\nComparison output is: %d",strcmp(str1,str2));

}
