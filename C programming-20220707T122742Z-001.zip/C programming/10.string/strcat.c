#include <stdio.h>
#include <string.h>

int main(void)
{
    char str1[20]={"ijas "};
    char str2[20];


    printf("Enter last name: ");
    scanf("%s",str2);

    strcat(str1, str2);
    printf("Your name is : %s", str1);
  

}
