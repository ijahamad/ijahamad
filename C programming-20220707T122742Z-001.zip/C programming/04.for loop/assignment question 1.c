#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
   for (x = 999; x >= 1; x -= 2)
    {
     printf("%d\n", x);

}
}
________________________________________________________________________________________________________________________________________________________________________________________________________________________________

1 #include <stdio.h>
2
3int main(void)
4 {
5 unsigned int x;
6 unsigned int y;
78
// prompt user for input
9 printf("%s", "Enter two unsigned integers in the range 1-20: ");
10 scanf("%u%u", &x, &y); // read values for x and y
11
12 for (unsigned int i = 1; i <= y; ++i) { // count from 1 to y
13
14 for (unsigned int j = 1; j <= x; ++j) { // count from 1 to x
15 printf("%s", "@");
16 }
17
18 puts(""); // begin new line
19 }
20 }
