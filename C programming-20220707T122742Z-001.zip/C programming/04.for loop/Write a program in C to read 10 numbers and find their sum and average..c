#include <stdio.h>
#include <stdlib.h>

int main(void)
{
   int i,sum=0;
float avg;

printf("10 natural numbers: \n");

   for(i=1;i<=10;i++)
   {
        printf("%d\n",i);
  sum+=i;
   }
avg=sum/10.0;
printf("The sum of 10 no is : %d\nThe Average is : %f\n",sum,avg);
}

__________________________________________________________________________________________________________________________________________


