01)

#include<stdio.h>

int main(void)
{
int i,sum=0;
float average;
printf("10 natural numbers:\n");
for(i=1;i<=10;i++)
{
printf("%d\n",i);
sum=sum+i;
average=sum/10.0;
}
printf("the sum is %d",sum);
printf("the average is %f",average);
}
----------------------------------------------------------------------
02)n terms.

#include <stdio.h>
#include <stdlib.h>

int main()
{
   int i,n;
float sum=0,avg;
printf("Ener the value: \n");
scanf("%d",&n);

printf("%d natural numbers: \n",n);

   for(i=1;i<=n;i++)
   {
        printf("%d\n",i);
  sum+=i;
   }
avg=sum/n;
printf("The sum of 10 no is : %d\nThe Average is : %f\n",sum,avg);




    return 0;
}