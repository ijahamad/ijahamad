#include <stdio.h>
#include <stdlib.h>




int main()
{
    int age1,age2,array[]={1,2,3,4,5};

   arr(array[0],array[1]);

}


void arr(int age1,int age2)
{
    printf("%d\n",age1);
    printf("%d\n",age2);
}
