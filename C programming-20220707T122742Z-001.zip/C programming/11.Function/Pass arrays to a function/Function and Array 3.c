#include <stdio.h>
#include <stdlib.h>




int main()
{
    int array[]={1,89,3,4,7};

   arr(array);

}


void arr(int array[])
{
   for (int i=0; i<5 ;i++)
   {
       printf("%d\n",array[i]);
   }
}
