#include <stdio.h>
#include <stdlib.h>


int main()
{
    int x,y,array[]={1,2,34,65,9};

   arr(array);
   arrayelement(array[1],array[2]);
    array_mult(array);

}


void arr(int array[])
{

   for (int i=0; i<5 ;i++)
   {
       printf("%d\n",array[i]);

   }
   printf(".............................");
}

int arrayelement(int x,int y)
{
     printf("\n%d %d\n",x,y);
     printf(".............................\n");
}

 void array_mult(int array[])
 {

 for (int i=0; i<5 ;i++)
   {

       array[i]=array[i]*2;
       printf("%d\n",array[i]);
   }

 }
