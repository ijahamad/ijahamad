01)Swap number.

#include <stdio.h>
#include <stdlib.h>

void swap_number (int,int);

int main(void)
{

    int a,b;
     printf("Enter a value: ");
    scanf("%d%d",&a,&b);

     printf("\nBefore swap :%d  %d\n",a,b);

    swap_number(a,b);


}

void swap_number (int a,int b)

{
    int z;

    z=a;
    a=b;
    b=z;

     printf("\nAfter swap :%d  %d",a,b);

}



