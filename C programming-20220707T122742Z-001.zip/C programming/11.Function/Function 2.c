01)

#include <stdio.h>
#include <stdlib.h>

int sum(int);

int main (void)
{
    int i;

    for(i=1;i<=10;i++)
    {
       printf("%d\n",sum (i));
    }
}

int sum(int x)
{
    int result;
    result=x*x;
    return result;
}

--------------------------------------------------------------------------------------------------
02)

#include <stdio.h>
#include <stdlib.h>

int printthis (int);

int main(void)
{
    int i;
    for(i=1;i<=10;i++)
    {


   printf("%d\n",printthis (i));
    }
}
int printthis (int n)
{

    return (n*n);

}


