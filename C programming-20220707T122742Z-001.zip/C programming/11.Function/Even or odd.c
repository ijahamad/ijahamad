01)Even or odd.

#include <stdio.h>
#include <stdlib.h>

void even_or_odd (int);

int main(void)

{
    int x;

    printf(" Enter the number:  ");
    scanf("%d",&x);

    even_or_odd (x);

}

void even_or_odd (int x)

{
    if(x%2==0)
    {
        printf("  The value is even.");
    }

      else
    {
        printf("  The value is odd.");
    }






}
