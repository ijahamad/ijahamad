01)

#include <stdio.h>
#include <stdlib.h>

int showthis(int x,int y)
{
    int result;

    result=(x*y)+3;
    return result;

}
int main(void)
{

    int abc=showthis(4,5)*10;
    printf("My  output :%d\n",abc);
}

-----------------------------------------------------------------------------
02)

#include <stdio.h>
#include <stdlib.h>


int multi(int,int);

 int  n1=10,n2=20;

int main()
{
printf("The total is:%d",multi(2,3));
}

int multi(int n1,int n2)
{
    int sum;


   sum=n1+n2;
   return sum;
}

