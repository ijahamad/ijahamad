#include <stdio.h>
#include <stdlib.h>

void showthis (int);

int main(void)
{
    int x;

    printf("Enter the number: ");
    scanf("%d",&x);


   showthis (x);
}

void showthis (int x)

{


   if (x%2==0)

   {
       printf("the number is even");
   }
   else
   {
       printf("the number is odd");
   }

}






