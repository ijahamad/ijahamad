01)1ST Method.

#include <stdio.h>
#include <stdlib.h>

int multi(int,int,int);
void show(int,int,int);

int main(void)
{
    int n1,n2,n3,i;

    printf("Enter the first number: ");
    scanf("%d",&n1);

    printf("Enter the second number: ");
    scanf("%d",&n2);

    printf("Enter the third number: ");
    scanf("%d",&n3);

    show(n1,n2,n3);
    i=multi(n1,n2,n3);

    printf("\nthe multiplication value is: %d\n",i);

    printf("after adding : %d",i+10);



}

void show(int n1,int n2,int n3)
{
    printf("the first number is: %d\n",n1);

    printf("the second number is: %d\n",n2);

    printf("the third number is: %d\n",n3);

}


int multi(int n1,int n2,int n3)
{
    int mult;
    mult=n1*n2*n3;
    return  mult;
}

-----------------------------------------------------------------------------------------------
02)2nd Method.


#include <stdio.h>
#include <stdlib.h>

void fun(int,int,int);
int multifun(int,int,int);

int main(void)
{
    int a,b,c;
    int x,i;


     printf("The first value is: ",a);
     scanf("%d",&a);

     printf("\nThe first value is: ",b);
     scanf("%d",&b);

     printf("\nThe first value is: ",c);
     scanf("%d",&c);

   fun(a,b,c);
   i=multifun(a,b,c);
   i=i+10;
printf("The value is:%d",i);

    return 0;
}

 void fun(int a,int b,int c)
{
   printf("The values are:\n%d\n%d\n%d\n",a,b,c);

}
int multifun(int a,int b,int c)
{
   int multiplication;
   multiplication=a*b*c;

   return ( multiplication);
}








