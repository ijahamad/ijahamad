#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a,b,i=0;
    again:

   printf("Enter first number: ");
   scanf("%d",&a);

   printf("Enter second number: ");
   scanf("%d",&b);

   printf("The total is : %d\n",a+b);
   i++;

   if(i<3)

   goto again;

}
------------------------------------------------------------------------------------------------
02)

#include <stdio.h>
void main()
{
   int i,j,rows;
   printf("First 10 numbers are: \n");


   i=0;
   again:
    printf("%d\n",i+1);
    i++;
      if(i<10)
  {

       goto again;
  }

}

