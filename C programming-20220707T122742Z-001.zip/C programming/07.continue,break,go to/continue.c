#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int i;

    for (i=1;i<=10;i++)
    {
        if (i==3)
       continue;
        printf("%d\n",i);
    }
     printf("ended");


}
