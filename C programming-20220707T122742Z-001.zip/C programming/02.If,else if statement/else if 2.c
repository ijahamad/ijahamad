#include <stdio.h>
int main(void)
{
    int a, b, c;

    printf(" Enter the number1 = ");
    scanf("%d", &a);

    printf("\n Enter the number2 = ");
    scanf("%d", &b);

    printf("\n Enter the number3 = ");
    scanf("%d", &c);

    if (a > b && a > c)

       {
        printf("\n Greatest number = %d \n",a);
       }

    else if (b > c && b > a)
    {
        printf("\n Greatest number = %d \n",b);
    }


    else
    {
        printf("\n Greatest number = %d \n",c);
    }

    return 0;
}
