#include <stdio.h>
#include <stdlib.h>

int main()
{
    int integer;

    printf("enter your marks: ");
    scanf("%d",&integer);

    if(integer>75)

    {
        printf("your grade is: %c",'A');
    }

    else if(integer>65)

    {
        printf("your grade is: %c",'B');
    }


    else if(integer>55)
    {
         printf("your grade is: %c",'C');
    }


    else if(integer>35)
    {
        printf("your grade is: %c",'s');
    }

     else
    {
        printf("your grade is: %c",'f');
    }





}
