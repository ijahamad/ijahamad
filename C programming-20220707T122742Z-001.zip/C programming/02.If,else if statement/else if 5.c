#include <stdio.h>
#include <stdlib.h>


int main(void)

{

   int character;

   printf("enter a character: ");
   scanf("%c",&character);

   if (character=='A')

   {
      printf("%c",'a');
   }

   else if(character=='B')

   {
      printf("%c",'b');
   }

   else if(character=='D')

    {
      printf("%c",'d');
    }

    else
    {
      printf("%c",'*');
    }







}
