#include<stdio.h>
int main()
{
int n=5,m=10;
if(n--*++m>50)
{
    printf("%d%d",n,m);
}

else
{
   printf("%d%d",m,n);
}
return 0;
}
