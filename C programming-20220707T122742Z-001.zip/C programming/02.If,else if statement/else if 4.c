#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int x;

    printf("enter the marks: ");
    scanf("%d",&x);


    if((100>x) && (x>80))
    {
    printf("your grade is %c",'A');

    }

     else if ((80>x) && (x>60))
    {
    printf("your grade is %c",'B');
    }

     else if ((60>x) && (x>40))

    {
    printf("your grade is %c",'C');
    }


     else if (40>x)

    {
      printf("your grade is %c",'F');
    }





}
