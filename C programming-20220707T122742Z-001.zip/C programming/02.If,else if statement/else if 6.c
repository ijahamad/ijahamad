#include <stdio.h>
#include <stdlib.h>


int main(void)

{

   int character;

   printf("enter a character: ");
   scanf("%c",&character);

   if (character=='A')

   {
      printf("%d",1);
   }

   else if(character=='B')

   {
      printf("%d",2);
   }

   else if(character=='C')

    {
      printf("%d",123);
    }

    else
    {
      printf("%c",'*');
    }







}

