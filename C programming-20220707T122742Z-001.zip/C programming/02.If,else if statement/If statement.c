#include <stdio.h>
#include <stdlib.h>

int main(void)

{
    int num;

    printf("enter a natural number: ");
    scanf("%d",&num);

    if (num%2==0)
    {
        printf("the number is even");
    }

    else
    {

     printf("the number is odd");
    }
}
