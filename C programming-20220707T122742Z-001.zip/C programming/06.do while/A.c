#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int i=1,count;

    printf("Enter  number of stars: ");
    scanf("%d",&count);

    do
    {
      printf("*\n");
     i++;
    } while(i<=count);

}
