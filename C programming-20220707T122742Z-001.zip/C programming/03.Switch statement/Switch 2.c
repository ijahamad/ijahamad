#include <stdio.h>
#include <stdlib.h>

int main(void)
{

   char operationalsymbol;
   double integer1,integer2;


    printf("enter an operator (+,-,*,/) : \n");
    scanf("%c",&operationalsymbol);


    printf("enter two numbers: ");
    scanf("%lf %lf",&integer1,&integer2);


    switch(operationalsymbol)
    {
    case '+':
        printf("%lf + %lf = %lf",integer1,integer2,integer1+integer2);
        break;
    case '-':
        printf("%lf - %lf = %lf",integer1,integer2,integer1-integer2);
        break;

    case '*':
        printf("%lf * %lf = %lf",integer1,integer2,integer1*integer2);
        break;
    case '/':
        printf("%lf / %lf = %lf",integer1,integer2,integer1/integer2);
        break;


    default:
         printf("invalid operation");





    }




}
