#include <stdio.h>
#include <stdlib.h>

int main(void)

{
    int integer;

    printf("enter the number: ");
    scanf("%d",&integer);

    switch(integer)

    {
        case 10:
        printf("number is equal to 10");
        break;
         case 50:
        printf("number is equal to 50");
        break;
         case 100:
        printf("number is equal to 100");
        break;
        default:
        printf("number is not equal to 10,50,100");







    }

}
