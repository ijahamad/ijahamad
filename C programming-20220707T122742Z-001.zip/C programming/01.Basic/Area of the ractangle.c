01)Area of the ractangle.

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int height,width,area;
    height=7;
    width=5;
    area=7*5;

   printf("Area of the ractangle = %d square inches",area);



}

--------------------------------------------------------------------------------------------------------------

02)Area of the ractangle.

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int height,width,area;
    area=height*width;

    printf("enter the height: ");
    scanf("%d",&height);

     printf("enter the width: ");
    scanf("%d",&width);



   printf("Area of the ractangle = %d square inches",area);



}

