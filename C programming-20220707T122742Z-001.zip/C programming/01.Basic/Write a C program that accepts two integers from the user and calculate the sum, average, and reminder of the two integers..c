01)Write a C program that accepts two integers from the user and calculate the sum, average, and reminder of the two integers.

#include <stdio.h>

int main (void)
{
    int x;
    int y;

    printf("enter the first integer: ");
    scanf("%d",&x);

    printf("enter the second integer: ");
    scanf("%d",&y);

    printf("the sum is %d\n",x+y);

    printf("the average is %d\n",(x+y)/2);

    printf("the reminder is %d\n",x%y);


}












