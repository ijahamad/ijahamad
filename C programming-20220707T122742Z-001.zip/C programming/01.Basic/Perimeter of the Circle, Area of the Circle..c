01)Perimeter of the Circle, Area of the Circle.

#include <stdio.h>
#include <stdlib.h>

int main(void)

{

    float perimeter,area,radius;
    radius=6;
    perimeter=2*3.14*radius;
    area=3.14*radius*radius;

    printf("Perimeter of the Circle= %0.2f\n",2*3.14*radius);
    printf("Area of the Circle= %0.2f\n",3.14*radius*radius);


}
