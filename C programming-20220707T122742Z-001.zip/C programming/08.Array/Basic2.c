#include <stdio.h>

int main(void)
{
    int months[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    int i;

   for(i=0;i<12;i++)
   {


    printf("%d days\n",months[i]);
}
}
