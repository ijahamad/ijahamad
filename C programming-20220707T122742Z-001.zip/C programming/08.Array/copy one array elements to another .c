#include <stdio.h>

void main()
{
    int j,i,n,a[100],b[100],sum=0;


  printf("input the number of element to store in the array");
  scanf("%d",&n);

    for(i=0;i<n;i++)
    {
        printf("Enter element - %d:\n",i);
        scanf("%d",&a[i]);
    }

    printf("\n ----------The values display------\n");
    for(j=0;j<n;j++)
    {
         printf("%d\n",a[j]);

    }

printf("\n ----------The values display in revers order------\n");

  for(j=n-1;j>=0;j--)
    {
         printf("%d\n",a[j]);
         sum+=a[j];
         b[j]=a[j];

    }
printf("\n ----------Sum of the elements------\n");

printf("sum :%d\n",sum);

printf("\n ----------print second array------\n");

for(j=0;j<n;j++)
    {
         printf("%d\n",b[j]);


    }


}