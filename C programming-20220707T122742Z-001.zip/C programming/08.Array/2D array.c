01)

#include <stdio.h>


int main(void)

{
   int a[2][5]={{3,4,5,6,2},{3,4,5,5,5}};
   int i,j;
 for(i=0;i<2;i++)
 {
     for(j=0;j<5;j++)
     {
         printf("%d",a[i][j]);
     }
     printf("\n");
 }


}

----------------------------------------------------------------------------------------------
02)

#include <stdio.h>
#include <string.h>
int main (void)
{
  int a[3][4];
   int i,j;

  for(i=0;i<3;i++)
  {
      for(j=0;j<4;j++)
      {
    printf ("Enter the value of [%d][%d]: \n",i,j);
    scanf("%d",&a[i][j]);
      }

  }

  printf ("\ntwo dimensional  array element are:\n");

    for(i=0;i<3;i++)
  {
      for(j=0;j<4;j++)
      {

    printf ("  %d\t",a[i][j]);

      }
printf("\n");

  }


}
