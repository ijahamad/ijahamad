#include <stdio.h>
#include <stdlib.h>

int main(void)
{
   int value[5];
   int i,j,average,sum=0;


   for (i=0;i<5;i++)
   {
       printf("enter %d number: ",i);
       scanf("%d",&value[i]);
   }
   for (j=0;j<5;j++)
   {
       printf("The %d number is:%d\n",j+1,value[j]);
       sum=sum+value[j];
   }
   average=sum/5;
   printf("The total is: %d",sum);
    printf("\nThe average is: %d",average);
}
