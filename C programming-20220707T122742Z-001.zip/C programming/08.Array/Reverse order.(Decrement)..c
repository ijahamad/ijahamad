01)Reverse order.(Decrement).

#include <stdio.h>

int main(void)
{
   int values[4]={7,5,9,2};

   for(int i=3;i>=0;i--)
   {
       printf("%d\t",values[i]);
   }


}
