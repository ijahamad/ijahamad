#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a[5]={5,27,64,18,95};
    int i,j;

       printf("%s%20s\n","element","value");

    for(i=0;i<5;i++)
     {

    printf("%7u%20d\n",i,a[i]);
     }

    for(i=0;i<5;i++)
    {

       for(j=1;j<=a[i];j++)
         {

        printf("*");
         }
          printf("\n");
    }




}
