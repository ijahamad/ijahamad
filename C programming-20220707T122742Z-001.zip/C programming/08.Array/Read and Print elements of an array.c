01)Write a program in C to store elements in an array and print it.

#include <stdio.h>
#define SIZE 10

int main(void)
{
    int a [SIZE];
    int i;
     printf("Enter the value: \n");

    for(i=0;i<10;i++)
    {
        scanf("%d",&a[i]);
    }

     for(i=0;i<10;i++)
    {
        printf("%d\n",a[i]);
    }
}
