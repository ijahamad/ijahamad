#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a[6];
    int i,j;

   printf("%s%20s\n","element","value");

   for(i=0;i<6;i++)
   {
       a[i]=2+i*5;
   }
    for(i=0;i<6;i++)
    {
        printf("%7d%20d\n",i,a[i]);
    }
    for(i=0;i<6;i++)
    {
        for(j=1;j<=a[i];j++)
        {


        printf("*");
        }

        printf("\n");

    }














 }
