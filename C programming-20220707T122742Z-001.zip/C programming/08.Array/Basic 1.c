#include <stdio.h>
#include <stdlib.h>

int main(void)
{  int a[5]={1,2,3,4,5};

    printf("%d",a[0]);
    printf("%d",a[1]);


}
