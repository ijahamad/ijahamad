#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a[5];
    char e[]="Element";
    char v[]="Value";
    int i;

    printf("%s%25s",e,v);

    for(i=0;i<5;i++)
    {
        a[i]=2+i*5;
    }

    for (i=0;i<5;i++)
    {
        printf("\n%d%28d",i,a[i]);
    }










 }


