Three dimensional  array.

#include <stdio.h>
#include <string.h>
int main (void)
{
    int i,j,k;
  int a[2][3][4]={
                {
                {1,3,4,2},
                {2,3,4,5},
                {2,2,1,9}
               },

               {
                {1,3,5,3},
                {8,7,9,2},
                {1,2,0,6}
               }
               };





  printf ("\nThree dimensional  array element are:\n");

    for(i=0;i<2;i++)
  {
      for(j=0;j<3;j++)
      {
         for(k=0;k<4;k++)
        {
            printf("%d\t",a[i][j][k]);

         }

     printf("\n");

      }
  printf("\n");

  }
printf("\n");

  }

